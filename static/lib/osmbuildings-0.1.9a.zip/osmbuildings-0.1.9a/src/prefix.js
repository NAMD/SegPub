var OSMBuildings = (function() {

    'use strict';

A loose but growing outline what's next steps for OSM Buildings.

# 0.2.0b

- separate rendering layer for flat buildings
- split data handling per layer
- handle render modes as plugins
- closer integration with existing map adapters, new adapters for ArcGIS, Google Maps and HERE
- roof color by building type
- support for new data sources
- first beta version, keeping API stable from now on
